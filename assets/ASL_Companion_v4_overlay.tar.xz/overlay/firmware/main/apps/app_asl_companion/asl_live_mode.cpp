// Arcade Home Labs: reuse StackChan 1.6.2 built-in AI audio, microphone, and dialog engine
// with the approved ASL Companion face. Original AI Agent and all other modes unchanged.
#include "asl_live_mode.h"
#include "asl_face_assets.h"
#include <hal/board/hal_bridge.h>
#include <esp_heap_caps.h>
#include <esp_log.h>
#include <esp_timer.h>
#include <atomic>
#include <string_view>

namespace asl_live {
namespace {
std::atomic<bool> mode_requested{false};
std::atomic<bool> speaking_requested{false};
std::atomic<bool> agent_standby_seen{false};
std::atomic<bool> greeting_started{false};
std::atomic<uint32_t> greeting_end_ms{0};
// Audio is a one-off character greeting using the user-approved reproducible
// eSpeak animated voice preset. Normal AI replies still use factory TTS.
constexpr uint32_t GREETING_DURATION_MS = 4582;
#ifndef ASL_HOST_TEST
extern const char greeting_begin[] asm("_binary_asl_companion_greeting_ogg_start");
extern const char greeting_end[] asm("_binary_asl_companion_greeting_ogg_end");
#endif
lv_obj_t* face = nullptr;
lv_image_dsc_t desc{};
uint8_t* indices = nullptr;
uint16_t* pixels = nullptr;
uint32_t next_frame_tick = 0;
size_t current_frame = 0;
asl_face::Sequence current_sequence = asl_face::Sequence::Idle;
uint32_t last_touch = 0;

void on_touch(lv_event_t*) {
    // Same touch-to-toggle-chat action as StackChan's original agent face.
    if (!hal_bridge::is_xiaozhi_ready()) return;
    const uint32_t now = static_cast<uint32_t>(esp_timer_get_time() / 1000);
    if (last_touch && now - last_touch < 2000) return;
    last_touch = now;
    hal_bridge::toggle_xiaozhi_chat_state();
}
}
void request() { mode_requested.store(true); }
bool requested() { return mode_requested.load(); }
void agent_standby() {
    if (requested()) agent_standby_seen.store(true);
}
void service_audio() {
    // Called from the update worker outside the display lock. Audio demuxing
    // is done only once, after the original audio service is fully ready.
    if (!requested() || !agent_standby_seen.load()) return;
    bool expected = false;
    if (!greeting_started.compare_exchange_strong(expected, true)) return;
    const uint32_t now = static_cast<uint32_t>(esp_timer_get_time() / 1000);
    greeting_end_ms.store(now + GREETING_DURATION_MS);
#ifdef ASL_HOST_TEST
    // The actual encoded sound is validated separately with ffprobe.
    hal_bridge::app_play_sound(std::string_view("OggS", 4));
#else
    hal_bridge::app_play_sound(std::string_view(greeting_begin,
       static_cast<size_t>(greeting_end - greeting_begin)));
#endif
}
void set_talking(bool value) {
    if (requested()) speaking_requested.store(value);
}
void mount(lv_obj_t* screen) {
    if (!requested() || face || !screen) return;
    indices = static_cast<uint8_t*>(heap_caps_malloc(asl_face::WIDTH * asl_face::HEIGHT, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    pixels = static_cast<uint16_t*>(heap_caps_malloc(asl_face::WIDTH * asl_face::HEIGHT * 2, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (!indices || !pixels) {
        ESP_LOGW("ASL_LIVE", "Not enough PSRAM for ASL face; keeping factory AI avatar");
        if (indices) heap_caps_free(indices);
        if (pixels) heap_caps_free(pixels);
        indices = nullptr; pixels = nullptr;
        return;
    }
    desc.header.magic = LV_IMAGE_HEADER_MAGIC;
    desc.header.cf = LV_COLOR_FORMAT_RGB565;
    desc.header.w = asl_face::WIDTH;
    desc.header.h = asl_face::HEIGHT;
    desc.header.stride = asl_face::WIDTH * 2;
    desc.data_size = asl_face::WIDTH * asl_face::HEIGHT * 2;
    desc.data = reinterpret_cast<const uint8_t*>(pixels);
    face = lv_image_create(screen);
    lv_obj_set_size(face, asl_face::WIDTH, asl_face::HEIGHT);
    lv_obj_align(face, LV_ALIGN_CENTER, 0, 0);
    lv_image_set_src(face, &desc);
    lv_obj_add_flag(face, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(face, on_touch, LV_EVENT_CLICKED, nullptr);
    speaking_requested.store(false);
    agent_standby_seen.store(false);
    greeting_started.store(false);
    greeting_end_ms.store(0);
    current_sequence = asl_face::Sequence::Idle;
    current_frame = 0; next_frame_tick = 0;
}
void reset() {
    if (face) {
        lv_obj_delete(face);
        lv_image_cache_drop(&desc);
        face = nullptr;
    }
    if (indices) heap_caps_free(indices);
    if (pixels) heap_caps_free(pixels);
    indices = nullptr; pixels = nullptr;
    mode_requested.store(false);
    speaking_requested.store(false);
    agent_standby_seen.store(false);
    greeting_started.store(false);
    greeting_end_ms.store(0);
    current_frame = 0; next_frame_tick = 0; last_touch = 0;
}
void tick(uint32_t now_ms) {
    if (!face || !indices || !pixels || !requested()) return;
    const bool is_greeting = greeting_started.load() &&
        static_cast<int32_t>(now_ms - greeting_end_ms.load()) < 0;
    const auto desired = (speaking_requested.load() || is_greeting) ?
        asl_face::Sequence::Talking : asl_face::Sequence::Idle;
    if (current_sequence != desired) {
        current_sequence = desired;
        current_frame = 0;
        next_frame_tick = 0;
    }
    if (next_frame_tick && static_cast<int32_t>(now_ms - next_frame_tick) < 0) return;
    const auto index = asl_face::sequence_start(current_sequence) + current_frame;
    if (!asl_face::decode_frame(index, indices, pixels)) {
        ESP_LOGW("ASL_LIVE", "Frame %u decode failed", static_cast<unsigned>(index));
        next_frame_tick = now_ms + 1000;
        return;
    }
    lv_image_cache_drop(&desc);
    lv_obj_invalidate(face);
    next_frame_tick = now_ms + asl_face::frames[index].duration_ms;
    current_frame = (current_frame + 1) % asl_face::sequence_count(current_sequence);
}
}
