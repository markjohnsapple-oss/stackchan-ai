// Arcade Home Labs: derived from owner-approved StackChan ASL GIFs.
#pragma once
#include <cstddef>
#include <cstdint>
namespace asl_face {
constexpr int WIDTH=320;
constexpr int HEIGHT=240;
constexpr int COLOURS=48;
enum class Sequence : uint8_t { Wakeup=0, Idle=1, Talking=2 };
struct Frame {
    uint32_t offset;
    uint32_t length;
    uint16_t duration_ms;
    uint16_t palette[COLOURS];
};
extern const Frame frames[];
extern const size_t frame_count;
extern const uint8_t compressed_data[];
extern const size_t compressed_size;
extern const uint16_t icon_pixels[160*128];
// Pure C++ decoder, separately tested on Linux before packaging.
bool decode_lz4_exact(const uint8_t* src, size_t src_len, uint8_t* dst, size_t dst_len);
bool decode_frame(size_t frame_id, uint8_t* indices, uint16_t* rgb565);
size_t sequence_start(Sequence s);
size_t sequence_count(Sequence s);
} // namespace asl_face
