// Arcade Home Labs ASL Companion mode, separate from factory apps.
#pragma once
#include <mooncake.h>
#include <lvgl.h>
#include <cstdint>
#include "asl_face_assets.h"
class AppAslCompanion : public mooncake::AppAbility {
public:
    AppAslCompanion();
    void onCreate() override;
    void onOpen() override;
    void onRunning() override;
    void onClose() override;
private:
    lv_obj_t* _panel=nullptr;
    lv_obj_t* _face=nullptr;
    lv_obj_t* _state_label=nullptr;
    uint8_t* _indices=nullptr;
    uint16_t* _pixels=nullptr;
    lv_image_dsc_t _picture{};
    asl_face::Sequence _sequence=asl_face::Sequence::Wakeup;
    size_t _frame_in_sequence=0;
    uint32_t _next_tick=0;
    bool show_frame();
    void set_sequence(asl_face::Sequence sequence);
    static void on_face_click(lv_event_t* e);
    static void on_back_click(lv_event_t* e);
};
