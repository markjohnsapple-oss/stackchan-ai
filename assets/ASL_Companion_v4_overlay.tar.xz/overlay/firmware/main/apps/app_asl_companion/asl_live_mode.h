// Arcade Home Labs: separate AI dialogue face bridge, opt-in for ASL Companion only.
#pragma once
#include <cstdint>
#include <lvgl.h>
namespace asl_live {
// Opt in only when the ASL menu app has completed its awakening sequence.
void request();
bool requested();
// Called inside the existing LVGL lock, once the built-in AI agent creates its display.
void mount(lv_obj_t* screen);
// Notify once the original AI service enters standby (audio engine ready).
void agent_standby();
// Queue the approved voice greeting once outside the display lock.
void service_audio();
// Receive speaking/idle state from the already-working speech service.
void set_talking(bool talking);
// Called from the existing StackChan UI update loop with LVGL already locked.
void tick(uint32_t now_ms);
// Restores the default display resources. Call with LVGL locked.
void reset();
}
