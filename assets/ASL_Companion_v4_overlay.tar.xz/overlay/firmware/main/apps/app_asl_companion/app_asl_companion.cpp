// Arcade Home Labs: isolated ASL Companion visual integration, no AI/microphone yet.
#include "app_asl_companion.h"
#include "asl_live_mode.h"
#include <hal/hal.h>
#include <mooncake_log.h>
#include <esp_heap_caps.h>
#include <cstring>

AppAslCompanion::AppAslCompanion() {
    setAppInfo().name="ASL Companion";
    static lv_image_dsc_t menu_icon{};
    menu_icon.header.magic=LV_IMAGE_HEADER_MAGIC;
    menu_icon.header.cf=LV_COLOR_FORMAT_RGB565;
    menu_icon.header.w=160;
    menu_icon.header.h=128;
    menu_icon.header.stride=160*2;
    menu_icon.data_size=160*128*2;
    menu_icon.data=reinterpret_cast<const uint8_t*>(asl_face::icon_pixels);
    setAppInfo().icon=static_cast<void*>(&menu_icon);
    static uint32_t theme_color=0x26315D;
    setAppInfo().userData=&theme_color;
}
void AppAslCompanion::onCreate() {}

void AppAslCompanion::onOpen() {
    // The original launcher and its AI/Avatar modes are not changed.
    _indices=static_cast<uint8_t*>(heap_caps_malloc(asl_face::WIDTH*asl_face::HEIGHT,
                                     MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
    _pixels=static_cast<uint16_t*>(heap_caps_malloc(asl_face::WIDTH*asl_face::HEIGHT*2,
                                     MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
    LvglLockGuard guard;
    _panel=lv_obj_create(lv_screen_active());
    lv_obj_remove_style_all(_panel);
    lv_obj_set_size(_panel,320,240);
    lv_obj_align(_panel,LV_ALIGN_CENTER,0,0);
    lv_obj_set_style_bg_opa(_panel,LV_OPA_COVER,0);
    lv_obj_set_style_bg_color(_panel,lv_color_hex(0x030A23),0);
    lv_obj_remove_flag(_panel,LV_OBJ_FLAG_SCROLLABLE);

    if(_indices && _pixels) {
        _picture.header.magic=LV_IMAGE_HEADER_MAGIC;
        _picture.header.cf=LV_COLOR_FORMAT_RGB565;
        _picture.header.w=asl_face::WIDTH;
        _picture.header.h=asl_face::HEIGHT;
        _picture.header.stride=asl_face::WIDTH*2;
        _picture.data_size=asl_face::WIDTH*asl_face::HEIGHT*2;
        _picture.data=reinterpret_cast<const uint8_t*>(_pixels);
        _face=lv_image_create(_panel);
        lv_image_set_src(_face,&_picture);
        lv_obj_center(_face);
        // The awakening clip automatically enters live chat. The original
        // speaking/idle animation switching then follows the speech service.
        set_sequence(asl_face::Sequence::Wakeup);
        _next_tick=0;
    } else {
        lv_obj_t* error_label=lv_label_create(_panel);
        lv_label_set_text(error_label,"Companion needs more free PSRAM");
        lv_obj_set_width(error_label,300);
        lv_label_set_long_mode(error_label,LV_LABEL_LONG_WRAP);
        lv_obj_center(error_label);
    }

    // Small unobtrusive return control ensures original StackChan always remains accessible.
    lv_obj_t* back=lv_button_create(_panel);
    lv_obj_set_size(back,58,24);
    lv_obj_align(back,LV_ALIGN_TOP_LEFT,4,4);
    lv_obj_set_style_bg_color(back,lv_color_hex(0x162140),0);
    lv_obj_add_event_cb(back,on_back_click,LV_EVENT_CLICKED,this);
    lv_obj_t* back_label=lv_label_create(back);
    lv_label_set_text(back_label,"BACK");
    lv_obj_set_style_text_color(back_label,lv_color_white(),0);
    lv_obj_center(back_label);

    _state_label=lv_label_create(_panel);
    lv_label_set_text(_state_label,"AWAKENING");
    lv_obj_set_style_text_color(_state_label,lv_color_hex(0xA9DFFF),0);
    lv_obj_align(_state_label,LV_ALIGN_TOP_RIGHT,-8,8);
}

void AppAslCompanion::onRunning() {
    if(!_indices || !_pixels || !_face) return;
    const uint32_t tick=GetHAL().millis();
    if (static_cast<int32_t>(tick-_next_tick)<0) return;
    LvglLockGuard lock;
    if (!show_frame()) { _next_tick=tick+1000; return; }
    const size_t first=asl_face::sequence_start(_sequence);
    const auto& current=asl_face::frames[first+_frame_in_sequence];
    _next_tick=tick+current.duration_ms;
    ++_frame_in_sequence;
    if(_frame_in_sequence>=asl_face::sequence_count(_sequence)) {
        if(_sequence==asl_face::Sequence::Wakeup) {
            // Wake-up has finished: hand off to the existing AI Agent's proven
            // microphone/voice service. Its display is given the ASL face.
            asl_live::request();
            GetHAL().requestXiaozhiStart();
            set_sequence(asl_face::Sequence::Idle);
        } else {
            _frame_in_sequence=0;
        }
    }
}

bool AppAslCompanion::show_frame() {
    const size_t index=asl_face::sequence_start(_sequence)+_frame_in_sequence;
    if(!asl_face::decode_frame(index,_indices,_pixels)) {
        mclog::tagError("ASL_COMPANION","failed decoding frame {}",index);
        return false;
    }
    // The face bitmap changes in-place; drop the cached decoded image before redraw.
    lv_image_cache_drop(&_picture);
    lv_obj_invalidate(_face);
    return true;
}

void AppAslCompanion::set_sequence(asl_face::Sequence sequence) {
    _sequence=sequence;
    _frame_in_sequence=0;
    if(_state_label) {
        lv_label_set_text(_state_label,
         sequence==asl_face::Sequence::Talking?"SPEAKING":
         sequence==asl_face::Sequence::Idle?"CONNECTING":"AWAKENING");
    }
}

void AppAslCompanion::on_face_click(lv_event_t* e) {
    auto* self=static_cast<AppAslCompanion*>(lv_event_get_user_data(e));
    (void)self; // Touch is handled by the live AI face after awakening.
}

void AppAslCompanion::on_back_click(lv_event_t* e) {
    auto* self=static_cast<AppAslCompanion*>(lv_event_get_user_data(e));
    if(self) self->close();
}

void AppAslCompanion::onClose() {
    {
        LvglLockGuard guard;
        if(_panel) lv_obj_delete(_panel);
        // Cached image descriptors must not outlive their PSRAM pixels.
        lv_image_cache_drop(&_picture);
        _panel=nullptr;
        _face=nullptr;
        _state_label=nullptr;
    }
    if(_indices) heap_caps_free(_indices);
    if(_pixels) heap_caps_free(_pixels);
    _indices=nullptr;
    _pixels=nullptr;
}
